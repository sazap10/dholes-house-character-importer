// Converts JSON strings to/from your types
// and asserts the results of JSON.parse at runtime
export class Convert {
    static toDholesHouseExportData(json) {
        return JSON.parse(json);
    }
    static dholesHouseExportDataToJson(value) {
        return JSON.stringify(value);
    }
}
