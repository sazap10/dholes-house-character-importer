export const registerSettings = function () {
    // Register any custom module settings here
};
